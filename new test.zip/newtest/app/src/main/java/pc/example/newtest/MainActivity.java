package pc.example.newtest;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    static Intent in;
    static int my_per=0;
RequestQueue requestqueue;
String url="http://192.168.43.88/include.php",url1="http://192.168.43.30/include1.php",map_url="";//String url="https://api.npoint.io/bb3b1ba563b6fab71b81";
TextView first_name,last_name,matricile,location,time,date;
WebView wv;
Button open_map;
@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
first_name=(TextView)findViewById(R.id.first_name);
last_name=(TextView)findViewById(R.id.last_name);
matricile=(TextView)findViewById(R.id.matricile);
 time=(TextView) findViewById(R.id.time);
 date=(TextView)findViewById(R.id.date);
 open_map=(Button)findViewById(R.id.open_map);
//location=(TextView)findViewById(R.id.location);



requestqueue= Volley.newRequestQueue(this);

    if(ContextCompat.checkSelfPermission(this, Manifest.permission.RECEIVE_SMS)!= PackageManager.PERMISSION_GRANTED){
        if(ActivityCompat.shouldShowRequestPermissionRationale(this,Manifest.permission.RECEIVE_SMS)){

        }else{
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECEIVE_SMS},my_per);

        }
    }
}

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if(requestCode==my_per){
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "thank you for permitting", Toast.LENGTH_SHORT).show();
            }else{
                Toast.makeText(this, "well I can't do anything until you permit me", Toast.LENGTH_SHORT).show();

            }
        }

connect();



    }
    public void connect(){
    //----------------------------------------------------------------------------------------------
        JsonObjectRequest jor=new JsonObjectRequest(url,null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                try{
                    JSONArray ja=response.getJSONArray("cartracker");

                   if(ja==null){
                   //   first_name.setText("");
                     //  last_name.setText("");
                       matricile.setText("");
                       time.setText("");
                       date.setText("");
                       location.setText("");
                   }else {
                       for (int i = 0; i < ja.length(); i++) {
                           JSONObject respons = ja.getJSONObject(i);
                           //String  = respons.getStri!ng("id");
                         //  String name = respons.getString("first_name");
                         //  first_name.setText(respons.getString("first_name"));
                           //last_name.setText((respons.getString("last_name")));
                           matricile.setText(respons.getString("matricile"));
                           time.setText(respons.getString("time"));
                           date.setText(respons.getString("date"));
                        //    location.setText(respons.getString("location"));
                           //String s = respons.getString("first_name");
                           wv = (WebView) findViewById(R.id.wv);
                           WebSettings ws = wv.getSettings();
                           ws.setJavaScriptEnabled(true);
                           wv.loadUrl(respons.getString("location"));
                          // wv.loadUrl("http://192.168.1.3/include.php");
                           wv.setWebViewClient(new WebViewClient());
                           map_url=respons.getString("location");
                            open_map.setVisibility(View.VISIBLE);
                            open_map.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    Intent intent=new Intent(Intent.ACTION_VIEW);
                                    intent.setData(Uri.parse("geo:35.63468,6.2752411"));
                                    Intent chooser=Intent.createChooser(intent,"lauch map");
                                    startActivity(chooser);

                                }
                            });

                       }
                   }

                }catch (JSONException e){
                    Toast.makeText(MainActivity.this,"application not working",Toast.LENGTH_SHORT).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(MainActivity.this,"application not working there is a problem with requesting data" +
                        " check your connexion",Toast.LENGTH_SHORT).show();
            }
        });


        requestqueue.add(jor);

refrech(100000);
    }

    private void refrech(int i) {
        final android.os.Handler h=new android.os.Handler();
        final Runnable r=new Runnable() {
            @Override
            public void run() {
              connect();
            }
        };
        h.postDelayed(r,i);
    }
public void check_internet(View view){

        checkinternetconnection cic=new checkinternetconnection(getApplicationContext());
        boolean ch=cic.isconnectedtointernet();
        if(!ch){
            Toast.makeText(MainActivity.this,"no internet connection",Toast.LENGTH_SHORT).show();
        }
        }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.mainactivity, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        //noinspection SimplifiableIfStatement
        switch (id){
            case R.id.add_client:
                //finish();

                 in=new Intent(getApplicationContext(),registration.class);

                startActivity(in);
                break;
            case R.id.exit:

                finish();
                break;
            case R.id.contact_us:
                Intent visite_site=new Intent(Intent.ACTION_VIEW);
                visite_site.setData(Uri.parse("http://cs.univ-batna2.dz/"));
                startActivity(visite_site);
                break;
            case R.id.about:
                break;



        }
        return super.onOptionsItemSelected(item);
    }
}



package pc.example.newtest;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.util.Log;
import android.widget.Toast;

public class MyReceiver extends BroadcastReceiver {
    static  String sms_rec="android.provider.Telephony.SMS_RECEIVED";
    static String tag="SmsBroadcastReceiver";
    static String msg,phone="";


    @Override
    public void onReceive(Context context, Intent intent) {

        Log.i(tag,"Intent Received"+intent.getAction());
        if(intent.getAction()==sms_rec){
            Bundle dataBundle=intent.getExtras() ;
            if(dataBundle!=null){
                Object[] myp=(Object[])dataBundle.get("pdus");
                final SmsMessage[] smsm=new SmsMessage[myp.length];
                for(int i=0;i<myp.length;i++){
                    if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.M){
                        String format=dataBundle.getString("format");
                        smsm[i]=SmsMessage.createFromPdu((byte[])myp[i],format);

                    }else{
                        smsm[i]=SmsMessage.createFromPdu((byte[])myp[i]);
                    }
                    msg=smsm[i].getMessageBody();
                    phone=smsm[i].getOriginatingAddress();
                }
                Toast.makeText(context,"msg="+msg+"n phone="+phone+"",Toast.LENGTH_SHORT).show();
                Intent i=new Intent(context,MainActivity.class);
                i.putExtra("msg",msg);
                i.putExtra("phone",phone);
                context.startActivity(i);
            }
        }
    }
}
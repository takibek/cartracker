package pc.example.newtest;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class login_activity extends AppCompatActivity {
    RequestQueue requestqueue;
    Button b1,b2;
    EditText t1,t2;
    String url="http://192.168.43.88/include2.php",username,password;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        b1=(Button)findViewById(R.id.b1);
        b2=(Button)findViewById(R.id.b2);
       t1=(EditText)findViewById(R.id.t1);
       t2=(EditText)findViewById(R.id.t2);

        requestqueue= Volley.newRequestQueue(this);
    }
    public void bt(View v){

        if(new checkinternetconnection(this.getApplicationContext()).isconnectedtointernet()!=true) {
            AlertDialog.Builder ab = new AlertDialog.Builder(login_activity.this);
            ab.setMessage("check your network")
                    .setTitle("erreur network")
                    .setIcon(R.drawable.network)
                    .setPositiveButton("ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    }).setNegativeButton("exit the app", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    finish();
                }
            }).show();
        }else {
            t1.setVisibility(View.VISIBLE);
            t2.setVisibility(View.VISIBLE);
            b1.setVisibility(View.INVISIBLE);
            b2.setVisibility(View.VISIBLE);


        }
    }
    public void login1(View v) throws InterruptedException {

        username=t1.getText().toString();
        password=t2.getText().toString();

        JsonObjectRequest jor=new JsonObjectRequest(url,null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try{
                    JSONArray ja=response.getJSONArray("admin");
                    String tab1[]=new String[ja.length()];
                    String tab2[]=new String[ja.length()];
                    if(ja==null){
                        //   first_name.setText("");
                        //  last_name.setText("");

                    }else {

                        for (int i = 0; i < ja.length(); i++) {
                            JSONObject respons = ja.getJSONObject(i);

                            tab1[i]=respons.getString("username");
                            tab2[i]=respons.getString("password");
                            //    location.setText(respons.getString("location"));
                            //String s = respons.getString("first_name");



                        }
                        boolean test=false;
                        for(int i=0;i<ja.length();i++){
                            if(tab1[i].equals(username)){
                                for (int j=0;j<ja.length();j++){
                                    if(tab2[j].equals(password)) {
                                        test=true;
                                        Thread.sleep(3000);
                                        AlertDialog.Builder ab = new AlertDialog.Builder(login_activity.this);
                                        ab.setMessage("please wait")
                                                .setTitle("................")
                                                .setIcon(R.drawable.network)
                                                .setPositiveButton("", new DialogInterface.OnClickListener() {
                                                    @Override
                                                    public void onClick(DialogInterface dialog, int which) {

                                                    }
                                                }).show();
                                        Intent in = new Intent(getApplicationContext(),MainActivity.class);
                                        startActivity(in);
                                        finish();
                                        break;
                                    }
                                }
                            }

                            if(test==false){
                                Toast.makeText(login_activity.this,"username or password invalid \n try again",Toast.LENGTH_SHORT).show();
                            }
                        }

                    }

                }catch (JSONException | InterruptedException e){
                    Toast.makeText(login_activity.this,"application not working",Toast.LENGTH_SHORT).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {


            }
        });


        requestqueue.add(jor);
    }
}

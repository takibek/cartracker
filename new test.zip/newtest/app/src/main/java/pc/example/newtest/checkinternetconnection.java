package pc.example.newtest;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

class checkinternetconnection {
    private Context context;
    public checkinternetconnection(Context context){
        this.context=context;
    }


    public boolean isconnectedtointernet(){
        ConnectivityManager cm=(ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if(cm!=null){
            NetworkInfo info=cm.getActiveNetworkInfo();
            if(info!=null && info.isConnected()){
                return  true;
            }
        }
            return false;

    }
}

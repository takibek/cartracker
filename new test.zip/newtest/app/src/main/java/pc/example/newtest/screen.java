package pc.example.newtest;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class screen extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.screen);
        Thread th = new Thread() {
            @Override
            public void run() {
                try {
                    Intent in = new Intent(getApplicationContext(), second_screen.class);
                    sleep(3000);
                    startActivity(in);
                    finish();

                } catch (Exception e) {

                }
            }
        };
        th.start();
    }
}
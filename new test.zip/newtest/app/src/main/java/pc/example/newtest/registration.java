package pc.example.newtest;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class registration extends AppCompatActivity {
    Button b1,b2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.new_registration);
            b1=(Button)findViewById(R.id.b1);
            b2=(Button)findViewById(R.id.b2);


            b1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent in_admin=new Intent(getApplicationContext(),addadmin.class);
                    startActivity(in_admin);
                }
            });
            b2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent in_client=new Intent(getApplicationContext(),addclient.class);
                    startActivity(in_client);

                }
            });

    }
}

package pc.example.newtest;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class second_screen extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.second_screen);
        Thread th = new Thread() {
            @Override
            public void run() {
                try {
                    Intent in = new Intent(getApplicationContext(),login_activity.class);
                    sleep(3000);
                    startActivity(in);
                    finish();

                } catch (Exception e) {

                }
            }
        };
        th.start();
    }
}